import mongoose from 'mongoose';

const menuItemSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  category: { type: String, default: 'Cakes' },
  price: { type: Number, required: true, min: 1 },
  image: { type: String, default: '' },
  tag: { type: String, default: '' },
  veg: { type: Boolean, default: true },
  available: { type: Boolean, default: true }
}, { timestamps: true });

const orderSchema = new mongoose.Schema({
  customer: { name: String, phone: String, email: String },
  address: { line1: String, landmark: String, area: String, city: String, pincode: String, coordinates: { lat: Number, lng: Number } },
  items: [{ menuItemId: mongoose.Schema.Types.ObjectId, name: String, unitPrice: Number, quantity: Number }],
  subtotal: Number, deliveryFee: Number, total: Number,
  paymentMethod: { type: String, enum: ['cod', 'razorpay'] },
  paymentStatus: { type: String, enum: ['pending', 'awaiting_payment', 'paid', 'failed'], default: 'pending' },
  paymentReference: String,
  status: { type: String, enum: ['received','confirmed','baking','ready','out_for_delivery','delivered','cancelled'], default: 'received' },
  notes: String
}, { timestamps: true });

export const MenuItem = mongoose.models.MenuItem || mongoose.model('MenuItem', menuItemSchema);
export const Order = mongoose.models.Order || mongoose.model('Order', orderSchema);
