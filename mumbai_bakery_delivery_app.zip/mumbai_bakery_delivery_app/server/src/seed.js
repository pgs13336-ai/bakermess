import 'dotenv/config';
import mongoose from 'mongoose';
import { MenuItem } from './models.js';
await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/mumbai_bakery');
const demo = [
  { name: 'Chocolate Truffle Cake', description: 'Rich chocolate ganache · eggless option on request', category: 'Cakes', price: 699, tag: 'Bestseller', image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=900', veg: true },
  { name: 'Red Velvet Cupcakes (4)', description: 'Soft red velvet with cream cheese-style frosting', category: 'Cupcakes', price: 299, tag: 'Popular', image: 'https://images.unsplash.com/photo-1486427944299-d1955d23e34d?w=900', veg: true },
  { name: 'Classic Butter Cookies', description: 'Small-batch baked, box of 8', category: 'Cookies', price: 199, tag: '', image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=900', veg: true },
  { name: 'Brownie Box (4)', description: 'Fudgy chocolate brownies', category: 'Brownies', price: 249, tag: 'Bestseller', image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=900', veg: true },
  { name: 'Vanilla Bento Cake', description: 'Mini celebration cake · custom message available', category: 'Cakes', price: 449, tag: 'Made to order', image: 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=900', veg: true },
  { name: 'Cinnamon Rolls (2)', description: 'Soft rolls with cinnamon sugar glaze', category: 'Fresh Bakes', price: 229, tag: 'Fresh today', image: 'https://images.unsplash.com/photo-1509365465985-25d11c17e812?w=900', veg: true }
];
await MenuItem.deleteMany({});
await MenuItem.insertMany(demo);
console.log(`Seeded ${demo.length} demo menu items`);
await mongoose.disconnect();
