import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import rateLimit from 'express-rate-limit';
import Razorpay from 'razorpay';
import crypto from 'node:crypto';
import { MenuItem, Order } from './models.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));

const PORT = process.env.PORT || 5000;
const hasRazorpay = Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);
const razorpay = hasRazorpay ? new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
}) : null;

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'Mumbai Bakery API' }));

app.get('/api/menu', async (_req, res) => {
  try {
    const items = await MenuItem.find({ available: true }).sort({ category: 1, name: 1 }).lean();
    res.json(items);
  } catch (e) { res.status(500).json({ message: 'Could not load menu' }); }
});

app.post('/api/orders', async (req, res) => {
  try {
    const { customer, address, items, paymentMethod, notes } = req.body || {};
    if (!customer?.name || !customer?.phone || !address?.line1 || !address?.pincode || !Array.isArray(items) || !items.length) {
      return res.status(400).json({ message: 'Name, phone, address, pincode and at least one item are required.' });
    }
    if (!/^[6-9]\d{9}$/.test(String(customer.phone).replace(/\D/g, '').slice(-10))) {
      return res.status(400).json({ message: 'Enter a valid 10-digit Indian mobile number.' });
    }
    const ids = items.map(i => String(i.menuItemId));
    const menu = await MenuItem.find({ _id: { $in: ids }, available: true }).lean();
    const byId = new Map(menu.map(i => [String(i._id), i]));
    const normalized = [];
    for (const row of items) {
      const product = byId.get(String(row.menuItemId));
      const qty = Number(row.quantity);
      if (!product || !Number.isInteger(qty) || qty < 1 || qty > 30) {
        return res.status(400).json({ message: 'One or more items are unavailable or have an invalid quantity.' });
      }
      normalized.push({ menuItemId: product._id, name: product.name, unitPrice: product.price, quantity: qty });
    }
    const subtotal = normalized.reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);
    const deliveryFee = subtotal >= 799 ? 0 : 49;
    const total = subtotal + deliveryFee;
    const allowed = ['cod', 'razorpay'];
    if (!allowed.includes(paymentMethod)) return res.status(400).json({ message: 'Choose a supported payment method.' });
    const order = await Order.create({
      customer: { name: String(customer.name).trim().slice(0, 100), phone: String(customer.phone).replace(/\D/g, '').slice(-10), email: String(customer.email || '').slice(0, 160) },
      address: { line1: String(address.line1).slice(0, 250), landmark: String(address.landmark || '').slice(0, 150), area: String(address.area || '').slice(0, 100), city: 'Mumbai', pincode: String(address.pincode).slice(0, 6), coordinates: address.coordinates || null },
      items: normalized, subtotal, deliveryFee, total, paymentMethod,
      paymentStatus: paymentMethod === 'cod' ? 'pending' : 'awaiting_payment',
      status: 'received', notes: String(notes || '').slice(0, 500)
    });
    res.status(201).json({ orderId: order._id, orderNumber: `MB-${String(order._id).slice(-6).toUpperCase()}`, total, status: order.status, paymentStatus: order.paymentStatus });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: 'Could not create order. Please try again.' });
  }
});

app.get('/api/orders/:id', async (req, res) => {
  try {
    const phone = String(req.query.phone || '').replace(/\D/g, '').slice(-10);
    const order = await Order.findById(req.params.id).lean();
    if (!order || phone !== order.customer.phone) return res.status(404).json({ message: 'Order not found. Check the order ID and phone number.' });
    res.json({ orderNumber: `MB-${String(order._id).slice(-6).toUpperCase()}`, status: order.status, paymentStatus: order.paymentStatus, total: order.total, items: order.items, createdAt: order.createdAt });
  } catch { res.status(400).json({ message: 'Invalid order ID.' }); }
});

app.patch('/api/orders/:id/status', async (req, res) => {
  if (!process.env.ADMIN_API_TOKEN || req.headers['x-admin-token'] !== process.env.ADMIN_API_TOKEN) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  const allowed = ['received', 'confirmed', 'baking', 'ready', 'out_for_delivery', 'delivered', 'cancelled'];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ message: 'Invalid status' });
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
    if (!order) return res.status(404).json({ message: 'Order not found' });
    res.json({ ok: true, status: order.status });
  } catch { res.status(400).json({ message: 'Invalid order ID' }); }
});

app.post('/api/payments/razorpay/order', async (req, res) => {
  if (!razorpay) return res.status(503).json({ message: 'Online payments are not configured. Use Cash on Delivery for now.' });
  const amount = Number(req.body.amount);
  if (!Number.isInteger(amount) || amount < 1 || amount > 10000000) return res.status(400).json({ message: 'Invalid amount' });
  try {
    const order = await razorpay.orders.create({ amount, currency: 'INR', receipt: `mb_${Date.now()}` });
    res.json({ id: order.id, amount: order.amount, currency: order.currency, keyId: process.env.RAZORPAY_KEY_ID });
  } catch { res.status(502).json({ message: 'Payment gateway could not create an order.' }); }
});

app.post('/api/payments/razorpay/verify', async (req, res) => {
  if (!hasRazorpay) return res.status(503).json({ message: 'Online payments are not configured.' });
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body || {};
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !orderId) return res.status(400).json({ message: 'Missing payment details' });
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  if (expected.length !== String(razorpay_signature).length || !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(String(razorpay_signature)))) {
    return res.status(400).json({ message: 'Payment verification failed' });
  }
  try {
    const order = await Order.findByIdAndUpdate(orderId, { paymentStatus: 'paid', paymentReference: razorpay_payment_id }, { new: true });
    if (!order) return res.status(404).json({ message: 'Bakery order not found' });
    res.json({ ok: true, paymentStatus: order.paymentStatus });
  } catch { res.status(400).json({ message: 'Invalid bakery order ID' }); }
});

await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/mumbai_bakery');
app.listen(PORT, () => console.log(`Bakery API listening on ${PORT}`));
