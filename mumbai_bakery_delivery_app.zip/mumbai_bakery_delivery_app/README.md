# Mumbai Bakery & Home Kitchen — Full-stack starter

A Swiggy-inspired ordering app for a home baker / small bakery in Mumbai. Includes:
- Customer storefront, menu categories, cart and checkout
- Browser GPS permission + manual address/pincode entry
- Delivery address and order notes
- Backend order API, menu API, admin order status API
- Razorpay Checkout integration with server-side signature verification (requires keys)
- MongoDB persistence with Mongoose
- Responsive UI for mobile and desktop

> This is a functional starter project, not a live production deployment. Configure credentials, test payments, add your real menu and delivery coverage, then deploy. Never put secret keys in frontend code.

## Requirements
- Node.js 20+
- MongoDB Atlas or local MongoDB
- Razorpay account for online payments (optional; Cash on Delivery is enabled in demo)
- Google Maps API key is optional; browser GPS uses the device permission and does not need a Maps key

## Run locally

### 1) Backend
```bash
cd server
cp .env.example .env
npm install
npm run dev
```
Fill in `MONGODB_URI`, `CLIENT_URL`, and Razorpay credentials if using online payments.

### 2) Frontend
In another terminal:
```bash
cd client
cp .env.example .env
npm install
npm run dev
```
Open the Vite URL shown in the terminal. The client defaults to `http://localhost:5173` and API to `http://localhost:5000`.

### Seed demo menu
```bash
cd server
npm run seed
```
This inserts sample bakery items. Replace them with your sister's real products, prices, photos and availability.

## Important setup before taking real orders
1. Change all demo branding and menu content.
2. Configure delivery zones, minimum order, delivery fee and hours.
3. Set a strong `JWT_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` and server-only Razorpay keys.
4. Use Razorpay test mode first. Checkout is wired in the frontend; payment confirmation is accepted only after server-side signature verification.
5. Configure HTTPS in production; browser GPS and payment callbacks require a secure origin (localhost is okay for development).
6. Add an authenticated admin login before exposing admin endpoints publicly. The starter has a simple shared admin token check for order-status changes; set `ADMIN_API_TOKEN`.
7. Configure MongoDB backups, logging, rate limits, privacy policy, refund/cancellation policy, food allergen information and FSSAI details as applicable.
8. For production delivery tracking, integrate a maps/routing provider and a driver workflow. This starter stores the customer's GPS coordinates and delivery address but does not provide live driver tracking.
9. Do not promise a delivery time until the kitchen confirms the order.

## Main routes
- `GET /api/health`
- `GET /api/menu`
- `POST /api/orders`
- `GET /api/orders/:id` (customer order lookup by order ID + phone)
- `PATCH /api/orders/:id/status` (requires `x-admin-token`)
- `POST /api/payments/razorpay/order`
- `POST /api/payments/razorpay/verify`

## Suggested production roadmap
- Phase 1: Menu, address, cart, COD/UPI/Razorpay, order confirmation.
- Phase 2: Admin login + kitchen order board + WhatsApp notifications.
- Phase 3: Delivery zone map, distance-based delivery fees, order status notifications.
- Phase 4: PWA installability, reviews, coupons, analytics, repeat-order tools.
